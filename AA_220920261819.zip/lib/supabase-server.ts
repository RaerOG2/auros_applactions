import {
  createServerClient,
} from "@supabase/ssr";

import {
  cookies,
} from "next/headers";


function getSupabaseConfig() {
  const supabaseUrl =
    process.env
      .NEXT_PUBLIC_SUPABASE_URL;

  const supabaseAnonKey =
    process.env
      .NEXT_PUBLIC_SUPABASE_ANON_KEY;


  if (
    !supabaseUrl ||
    !supabaseAnonKey
  ) {
    throw new Error(
      "Missing Supabase environment variables."
    );
  }


  return {
    supabaseUrl,
    supabaseAnonKey,
  };
}


export async function createSupabaseServerClient() {
  const cookieStore =
    await cookies();


  const {
    supabaseUrl,
    supabaseAnonKey,
  } =
    getSupabaseConfig();


  return createServerClient(
    supabaseUrl,
    supabaseAnonKey,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },

        setAll(
          cookiesToSet
        ) {
          try {
            cookiesToSet.forEach(
              ({
                name,
                value,
                options,
              }) => {
                cookieStore.set(
                  name,
                  value,
                  options
                );
              }
            );
          } catch {
            /*
             * Server Components cannot
             * always write cookies.
             *
             * middleware.ts refreshes
             * the Supabase session,
             * therefore this is safe
             * to ignore here.
             */
          }
        },
      },
    }
  );
}